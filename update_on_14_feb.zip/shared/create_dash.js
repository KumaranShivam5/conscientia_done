

//UNIVERSAL FUNCTION DEFINITION FOR GETTING COOKIE



function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function logout(){
    document.cookie="profdata=; expires =Thu, 01 jan 1987 00:00:00 UTC;";
    window.location="http://conscientia.co.in";
}